document.addEventListener('DOMContentLoaded', () => {
    // --- STATE VARIABLES & LOCAL STORAGE KEYS ---
    let isAuthenticated = false;
    let currentSlide = 0;
    const slides = document.querySelectorAll('.carousel-slide .slide');
    const totalSlides = slides.length;
    const BOOKINGS_KEY = 'venueBookings';
    const USERS_KEY = 'registeredUsers'; 

    // --- DOM ELEMENTS ---
    const splashScreen = document.getElementById('splash-screen');
    const mainContent = document.getElementById('main-content');
    const loginCard = document.getElementById('login-card');
    const registerCard = document.getElementById('register-card');
    const loginForm = document.getElementById('login-form');
    const registerForm = document.getElementById('register-form');
    // NEW: Tracking Form elements
    const trackingForm = document.getElementById('tracking-form'); 
    const trackingCard = document.getElementById('tracking-card');

    const showRegisterBtn = document.getElementById('show-register-btn');
    const showLoginBtn = document.getElementById('show-login-btn');
    const logoutBtn = document.getElementById('logout-btn');
    const userIconToggle = document.getElementById('user-icon-toggle');
    const userDropdown = document.getElementById('user-dropdown');
    const currentUsernameSpan = document.getElementById('current-username');
    
    // ADMIN & NAV ELEMENTS
    const navHome = document.getElementById('nav-home');
    const navVenues = document.getElementById('nav-venues');
    const navBookings = document.getElementById('nav-bookings');
    const navAdminReview = document.getElementById('nav-admin-review');
    const venueSelect = document.getElementById('venue-select');
    const adminBookingsTableBody = document.querySelector('#admin-bookings-table tbody');


    // --- USER MANAGEMENT FUNCTIONS ---

    // Initializes with a default user and a default admin if no users exist
    const getUsers = () => {
        const users = localStorage.getItem(USERS_KEY);
        if (!users) {
            return [
                // UPDATED: Added organization field to default users
                { username: 'test', password: 'password', email: 'test@portal.com', type: 'faculty', organization: 'College of Sciences' },
                { username: 'admin', password: 'adminpassword', email: 'admin@portal.com', type: 'admin_officer', organization: 'Administration' } // DEFAULT ADMIN
            ];
        }
        return JSON.parse(users);
    };

    const saveUsers = (users) => {
        localStorage.setItem(USERS_KEY, JSON.stringify(users));
    };
    
    const getBookings = () => {
        const bookings = localStorage.getItem(BOOKINGS_KEY);
        return bookings ? JSON.parse(bookings) : [];
    };

    const saveBookings = (bookings) => {
        localStorage.setItem(BOOKINGS_KEY, JSON.stringify(bookings));
    };

    // --- AUTHENTICATION FLOW ---

    const navigateToApp = (username) => {
        isAuthenticated = true;
        
        const users = getUsers();
        const user = users.find(u => u.username === username);
        const isAdmin = user && user.type === 'admin_officer';
        
        localStorage.setItem('isAuthenticated', 'true');
        localStorage.setItem('currentUsername', username);
        localStorage.setItem('isAdmin', isAdmin ? 'true' : 'false'); 

        // UI Updates
        splashScreen.classList.add('hidden');
        mainContent.classList.remove('hidden');
        currentUsernameSpan.textContent = username;
        userIconToggle.textContent = username.toUpperCase().charAt(0);
        document.title = `Portal - Logged in as ${username}`; 
        
        if (isAdmin) {
            navHome.classList.add('hidden-admin');
            navBookings.classList.add('hidden-admin');
            navVenues.classList.remove('hidden-admin');
            navAdminReview.classList.remove('hidden-admin');
            
            switchPortalTab('admin-review-tab'); 
        } else {
            navHome.classList.remove('hidden-admin');
            navBookings.classList.remove('hidden-admin');
            navVenues.classList.remove('hidden-admin');
            navAdminReview.classList.add('hidden-admin');
            
            switchPortalTab('home-tab'); 
        }
    };

    const navigateToAuth = () => {
        isAuthenticated = false;
        
        localStorage.removeItem('isAuthenticated');
        localStorage.removeItem('currentUsername');
        localStorage.removeItem('isAdmin');

        // UI Updates
        splashScreen.classList.remove('hidden');
        mainContent.classList.add('hidden');
        loginCard.classList.remove('hidden');
        registerCard.classList.add('hidden');
        document.title = `Venue Booking Portal`;
    };

    // Check for existing session on load
    const checkSession = () => {
        const storedAuth = localStorage.getItem('isAuthenticated');
        const storedUser = localStorage.getItem('currentUsername');
        
        if (storedAuth === 'true' && storedUser) {
            navigateToApp(storedUser); 
        } else {
            // Initial delay to show splash screen before login card pops up
            setTimeout(() => {
                splashScreen.classList.remove('hidden');
                loginCard.classList.remove('hidden');
            }, 100); 
        }
    };


    // --- EVENT LISTENERS (AUTH & REGISTER) ---

    // Login Form Submission
    loginForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const usernameOrEmail = document.getElementById('login-username').value.trim();
        const password = document.getElementById('login-password').value.trim();
        const errorElement = document.getElementById('error-message');
        
        const users = getUsers();
        
        const user = users.find(u => 
            (u.username === usernameOrEmail || u.email === usernameOrEmail) && u.password === password
        );

        if (user) {
            errorElement.textContent = '';
            navigateToApp(user.username);
        } else {
            errorElement.textContent = 'Invalid username, email, or password.';
        }
    });

    // Register Form Submission
    registerForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const username = document.getElementById('register-username').value.trim();
        const registerType = document.getElementById('register-type').value; 
        const email = document.getElementById('register-email').value.trim();
        // NEW: Get Organization value
        const organization = document.getElementById('register-organization').value.trim();
        const password = document.getElementById('register-password').value.trim();
        const errorElement = document.getElementById('register-error-message');

        const users = getUsers();

        if (!username || !registerType || !email || password.length < 6) {
            errorElement.textContent = 'Please fill out all required fields. Password must be at least 6 characters.';
            errorElement.style.color = '#d32f2f';
            return;
        }

        const existingUser = users.find(u => u.username === username || u.email === email);
        if (existingUser) {
            errorElement.textContent = 'Username or email is already registered.';
            errorElement.style.color = '#d32f2f';
            return;
        }
        
        const newUser = { 
            username, 
            email, 
            password, 
            type: registerType,
            organization: organization // NEW: Save Organization
        };
        users.push(newUser);
        saveUsers(users);

        errorElement.textContent = 'Registration successful! You can now log in.';
        errorElement.style.color = '#00A99D';
        
        setTimeout(() => {
            loginCard.classList.remove('hidden');
            registerCard.classList.add('hidden');
            errorElement.textContent = '';
            registerForm.reset();
            loginForm.reset();
        }, 1500);
    });
    
    // Switch between Login/Register tabs
    showRegisterBtn.addEventListener('click', () => {
        loginCard.classList.add('hidden');
        registerCard.classList.remove('hidden');
        document.getElementById('error-message').textContent = '';
    });

    showLoginBtn.addEventListener('click', () => {
        loginCard.classList.remove('hidden');
        registerCard.classList.add('hidden');
        document.getElementById('register-error-message').textContent = '';
    });
    
    logoutBtn.addEventListener('click', navigateToAuth);

    userIconToggle.addEventListener('click', () => {
        userDropdown.classList.toggle('show');
    });

    // Close dropdown if clicking outside
    window.addEventListener('click', (e) => {
        if (!userIconToggle.contains(e.target) && !userDropdown.contains(e.target)) {
            userDropdown.classList.remove('show');
        }
    });
    
    // --- TRACKING SYSTEM LOGIC (Unchanged) ---
    trackingForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const trackingIdInput = document.getElementById('tracking-id');
        const resultDiv = document.getElementById('tracking-result');
        
        // Ensure the ID is parsed as a number (since we use Date.now() for IDs)
        const trackingId = parseInt(trackingIdInput.value.trim()); 
        
        if (isNaN(trackingId)) {
            resultDiv.innerHTML = '<p style="color: red;">Invalid Reference ID format.</p>';
            return;
        }

        const allBookings = getBookings(); 
        const booking = allBookings.find(b => b.id === trackingId);
        
        const venueNameMap = {
            'ballroom': 'Grand Ballroom',
            'boardroom': 'Executive Boardroom',
            'terrace': 'Rooftop Terrace'
        };

        if (booking) {
            resultDiv.innerHTML = `
                <p><strong>Reference ID:</strong> ${booking.id}</p>
                <p><strong>Venue:</strong> ${venueNameMap[booking.venue] || booking.venue}</p>
                <p><strong>Date:</strong> ${booking.date}</p>
                <p><strong>Purpose:</strong> ${booking.purpose.substring(0, 30)}${booking.purpose.length > 30 ? '...' : ''}</p>
                <p style="margin-top: 10px;">
                    <strong>Approval Status:</strong> <span class="status-${booking.approvalStatus.toLowerCase().replace(' ', '-')}">${booking.approvalStatus}</span>
                </p>
                <p>
                    <strong>Payment Status:</strong> <span class="status-${booking.paymentStatus.toLowerCase()}">${booking.paymentStatus}</span>
                </p>
            `;
            resultDiv.style.border = '1px solid #00A99D';
        } else {
            resultDiv.innerHTML = '<p style="color: red;">No booking found with that Reference ID.</p>';
            resultDiv.style.border = '1px solid red';
        }
    });


    // --- PORTAL NAVIGATION & TABS (Unchanged) ---
    const portalTabs = document.querySelectorAll('.portal-tab');
    const navLinks = document.querySelectorAll('.sticky-header nav a');
    const bookingTabBtns = document.querySelectorAll('.booking-system-container .tab-btn');

    const switchBookingSubTab = (contentId) => {
        document.querySelectorAll('.tab-content').forEach(content => content.classList.remove('active'));
        document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
        
        document.getElementById(contentId).classList.add('active');
        document.querySelector(`.tab-btn[data-tab-content="${contentId}"]`).classList.add('active');
    };

    const switchPortalTab = (tabId) => {
        portalTabs.forEach(tab => tab.classList.remove('active'));
        navLinks.forEach(link => link.classList.remove('active'));
        
        document.getElementById(tabId).classList.add('active');
        const activeNav = document.querySelector(`[data-tab="${tabId}"]`);
        if(activeNav) {
            activeNav.classList.add('active');
        }

        if (tabId === 'bookings-tab') {
            renderBookingsTable();
            switchBookingSubTab('new-booking-content');
        } else if (tabId === 'admin-review-tab') {
            if (localStorage.getItem('isAdmin') === 'true') {
                 renderAdminBookingsTable(); 
            }
        }
    };
    
    navLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const tabId = e.target.getAttribute('data-tab');
            switchPortalTab(tabId);
        });
    });

    bookingTabBtns.forEach(btn => {
        btn.addEventListener('click', (e) => {
            const contentId = e.target.getAttribute('data-tab-content');
            switchBookingSubTab(contentId);
        });
    });

    const handleBookingRedirect = (venueId = null) => {
        switchPortalTab('bookings-tab'); 
        switchBookingSubTab('new-booking-content'); 
        
        if (venueId && venueSelect) {
            venueSelect.value = venueId; 
        }
    };

    document.querySelectorAll('.book-now-btn').forEach(button => {
        button.addEventListener('click', (e) => {
            const venueId = e.target.getAttribute('data-venue-id');
            handleBookingRedirect(venueId);
        });
    });

    document.querySelectorAll('.card-book-btn').forEach(button => {
        if (!button.disabled) {
            button.addEventListener('click', (e) => {
                const venueId = e.target.getAttribute('data-venue-id');
                handleBookingRedirect(venueId);
            });
        }
    });

    // --- CAROUSEL FUNCTIONALITY (Unchanged) ---
    const carouselSlide = document.getElementById('venue-carousel');
    const prevBtn = document.querySelector('.prev-btn');
    const nextBtn = document.querySelector('.next-btn');
    
    const updateCarousel = () => {
        carouselSlide.style.transform = `translateX(-${currentSlide * 100}%)`;
    };

    prevBtn.addEventListener('click', () => {
        currentSlide = (currentSlide === 0) ? totalSlides - 1 : currentSlide - 1;
        updateCarousel();
    });

    nextBtn.addEventListener('click', () => {
        currentSlide = (currentSlide === totalSlides - 1) ? 0 : currentSlide + 1;
        updateCarousel();
    });

    setInterval(() => {
        currentSlide = (currentSlide === totalSlides - 1) ? 0 : currentSlide + 1;
        updateCarousel();
    }, 5000);


    // --- BOOKING SYSTEM (USER VIEW) (Unchanged Logic, just using updated user data) ---
    
    const renderBookingsTable = () => {
        const tableBody = document.querySelector('#bookings-table tbody');
        const user = localStorage.getItem('currentUsername');
        const allBookings = getBookings();
        const userBookings = allBookings.filter(b => b.username === user);
        
        tableBody.innerHTML = ''; 

        if (userBookings.length === 0) {
            // Updated colspan from 6 to 7
            tableBody.innerHTML = '<tr><td colspan="7" style="text-align: center; color: #8C99A0;">No upcoming reservations found.</td></tr>';
            return;
        }

        const venueNameMap = {
            'ballroom': 'Grand Ballroom',
            'boardroom': 'Executive Boardroom',
            'terrace': 'Rooftop Terrace'
        };

        userBookings.forEach((booking) => {
            const row = tableBody.insertRow();
            
            // Reference ID Column
            row.insertCell().textContent = booking.id; 
            
            row.insertCell().textContent = venueNameMap[booking.venue] || booking.venue;
            row.insertCell().textContent = booking.date;
            row.insertCell().textContent = `${booking.startTime} - ${booking.endTime}`;
            
            // PURPOSE / APPROVAL STATUS & FILES COUNT
            const purposeCell = row.insertCell();
            const fileCount = booking.files && booking.files.length > 0 ? ` (+${booking.files.length} Docs)` : '';
            purposeCell.innerHTML = `
                ${booking.purpose.substring(0, 30)}${booking.purpose.length > 30 ? '...' : ''}${fileCount}<br>
                <span class="status-${booking.approvalStatus.toLowerCase().replace(' ', '-')}">
                    (${booking.approvalStatus})
                </span>
            `;

            // PAYMENT STATUS
            const paymentCell = row.insertCell();
            paymentCell.textContent = booking.paymentStatus;
            paymentCell.style.fontWeight = 'bold';
            paymentCell.style.color = booking.paymentStatus === 'Paid' ? '#00A99D' : '#d32f2f'; 

            const actionCell = row.insertCell();
            const cancelButton = document.createElement('button');
            cancelButton.classList.add('cancel-btn');

            if (booking.approvalStatus !== 'Pending Review') {
                cancelButton.disabled = true;
                cancelButton.style.backgroundColor = '#ccc';
                cancelButton.style.cursor = 'not-allowed';
                cancelButton.textContent = 'Review Locked';
            } else {
                cancelButton.textContent = 'Cancel';
                cancelButton.onclick = () => cancelBooking(booking.id);
            }
            actionCell.appendChild(cancelButton);
        });
    };

    // Booking form submission (ASYNC to handle file reading)
    document.getElementById('booking-form').addEventListener('submit', async (e) => {
        e.preventDefault();
        
        const venue = document.getElementById('venue-select').value;
        const date = document.getElementById('booking-date').value;
        const startTime = document.getElementById('start-time').value;
        const endTime = document.getElementById('end-time').value;
        const purpose = document.getElementById('booking-purpose').value.trim(); 
        const fileInput = document.getElementById('booking-files'); 
        const user = localStorage.getItem('currentUsername');

        if (!venue || !date || !startTime || !endTime || !purpose) {
            alert('Please fill out all required booking details.');
            return;
        }
        
        // --- FILE READING LOGIC ---
        const filesArray = Array.from(fileInput.files);
        const fileData = [];

        const fileToBase64 = (file) => new Promise((resolve, reject) => {
            if (file.size > 1024 * 1024) { // 1MB limit check
                reject(new Error(`File "${file.name}" is too large (>1MB) and cannot be stored locally.`));
                return;
            }

            const reader = new FileReader();
            reader.onload = () => resolve({
                name: file.name,
                type: file.type,
                dataURL: reader.result 
            });
            reader.onerror = (error) => reject(error);
            reader.readAsDataURL(file);
        });

        try {
            const filePromises = filesArray.map(fileToBase64);
            const convertedFiles = await Promise.all(filePromises);
            fileData.push(...convertedFiles);

        } catch (error) {
            alert(`File Error: ${error.message}`);
            return; 
        }
        // --- END FILE READING LOGIC ---
        
        // Use Date.now() for unique Reference ID
        const newBookingId = Date.now(); 

        const newBooking = {
            id: newBookingId, 
            username: user,
            venue: venue,
            date: date,
            startTime: startTime,
            endTime: endTime,
            purpose: purpose, 
            files: fileData, 
            paymentStatus: 'Pending',
            approvalStatus: 'Pending Review' 
        };

        const currentBookings = getBookings();
        currentBookings.push(newBooking);
        saveBookings(currentBookings);

        // UPDATED: Alert now shows the Reference ID
        alert(`Booking requested successfully!\nYour Reference ID is: ${newBookingId}.\nYour request is set to: ${newBooking.approvalStatus}. You uploaded ${fileData.length} document(s).`);
        
        document.getElementById('booking-form').reset();
        
        switchBookingSubTab('view-bookings-content'); 
    });

    const cancelBooking = (bookingId) => {
        if (!confirm('Are you sure you want to cancel this booking?')) {
            return;
        }

        let currentBookings = getBookings();
        const updatedBookings = currentBookings.filter(booking => booking.id !== bookingId);

        saveBookings(updatedBookings);
        alert('Booking cancelled successfully.');
        renderBookingsTable(); 
        if (localStorage.getItem('isAdmin') === 'true') {
             renderAdminBookingsTable(); 
        }
    };


    // --- ADMIN DASHBOARD LOGIC ---

    // Function to handle Admin action (must be a global function)
    window.handleAdminAction = (bookingId, action) => {
        let bookings = getBookings();
        const bookingIndex = bookings.findIndex(b => b.id === bookingId);

        if (bookingIndex !== -1) {
            const statusMap = {
                'approve': 'Approved',
                'deny': 'Denied',
                'pay': 'Paid',
                'pending': 'Pending'
            };

            if (action === 'approve' || action === 'deny') {
                 bookings[bookingIndex].approvalStatus = statusMap[action];
            } else if (action === 'pay' || action === 'pending') {
                 bookings[bookingIndex].paymentStatus = statusMap[action];
            }

            saveBookings(bookings);
            renderAdminBookingsTable(); 
            renderBookingsTable(); 
        }
    };

    // UPDATED: Now displays user's organization
    const renderAdminBookingsTable = () => {
        const allBookings = getBookings();
        const users = getUsers();
        adminBookingsTableBody.innerHTML = '';

        if (allBookings.length === 0) {
            // Updated colspan from 7 to 8
            adminBookingsTableBody.innerHTML = '<tr><td colspan="8" style="text-align: center; color: #8C99A0;">No bookings have been made yet.</td></tr>';
            return;
        }
        
        const sortedBookings = allBookings.sort((a, b) => {
            if (a.approvalStatus === 'Pending Review' && b.approvalStatus !== 'Pending Review') return -1;
            if (a.approvalStatus !== 'Pending Review' && b.approvalStatus === 'Pending Review') return 1;
            return new Date(a.date) - new Date(b.date);
        });

        sortedBookings.forEach((booking) => {
            const user = users.find(u => u.username === booking.username) || {};
            const row = adminBookingsTableBody.insertRow();
            
            const venueNameMap = {
                'ballroom': 'Grand Ballroom',
                'boardroom': 'Executive Boardroom',
                'terrace': 'Rooftop Terrace'
            };
            
            // NEW: Reference ID Column
            row.insertCell().textContent = booking.id; 
            
            // 1. User
            row.insertCell().textContent = booking.username;
            
            // 2. Role (UPDATED: Now includes Organization)
            row.insertCell().innerHTML = `
                ${user.type || 'N/A'}<br>
                <strong>Org:</strong> ${user.organization || 'N/A'}
            `;
            
            // 3. Venue and Date/Time
            row.insertCell().innerHTML = `
                <strong>${venueNameMap[booking.venue]}</strong><br>
                ${booking.date} (${booking.startTime} - ${booking.endTime})
            `;
            
            // 4. Purpose/Requirements and Approval Status (Including file links)
            const filesHtml = (booking.files && booking.files.length > 0) 
                ? '<strong>Documents:</strong> ' + booking.files.map(
                    (file, index) => `<a href="${file.dataURL}" download="${file.name}" style="color: #00A99D;">File ${index + 1}</a>`
                ).join(' | ')
                : 'No documents attached.';
            
            row.insertCell().innerHTML = `
                <strong>Purpose:</strong> ${booking.purpose}<br><br>
                ${filesHtml}<br><br>
                <span class="status-${booking.approvalStatus.toLowerCase().replace(' ', '-')}">
                    Approval: ${booking.approvalStatus}
                </span>
            `;

            // 5. Payment Status (with action button)
            const paymentCell = row.insertCell();
            paymentCell.innerHTML = `
                <span class="status-${booking.paymentStatus.toLowerCase()}">
                    ${booking.paymentStatus}
                </span><br>
                <button class="approve-btn" style="margin-top: 5px;" onclick="handleAdminAction(${booking.id}, '${booking.paymentStatus === 'Paid' ? 'pending' : 'pay'}')">
                    ${booking.paymentStatus === 'Paid' ? 'Mark Pending' : 'Mark Paid'}
                </button>
            `;

            // 6. Actions (Approve/Deny)
            const actionsCell = row.insertCell();
            actionsCell.classList.add('action-buttons');
            
            if (booking.approvalStatus === 'Pending Review') {
                actionsCell.innerHTML = `
                    <button class="approve-btn" onclick="handleAdminAction(${booking.id}, 'approve')">Approve</button>
                    <button class="deny-btn" onclick="handleAdminAction(${booking.id}, 'deny')">Deny</button>
                `;
            } else {
                actionsCell.innerHTML = `
                    <span class="status-${booking.approvalStatus.toLowerCase().replace(' ', '-')}">
                        ${booking.approvalStatus}
                    </span>
                `;
            }
        });
    };


    // --- INITIALIZATION ---
    checkSession();
});